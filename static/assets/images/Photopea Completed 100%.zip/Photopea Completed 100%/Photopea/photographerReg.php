<?php
include './COMMON/commonheader.php';
?>

<!-- contact -->
<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Photographer Registration </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
            <div class="row contact-block .text-center" style="justify-content: center;">
                <div class="col-md-7 contact-right mt-md-0 mt-4">
                    <form method="post">
                        <div class="input-grids">
                            <input type="text" name="fname" id="w3lName" placeholder="Full Name" class="contact-input" required="" />
                            <input type="text" name="phone" maxlength="10" pattern =[789][0-9]{9} id="w3lName" placeholder="Phone Number" class="contact-input" required="" />
                            <input type="email" name="email" id="w3lSender" placeholder="Email" class="contact-input" required="" />
                            <input type="text" name="exp" id="w3lSender" placeholder="Specialiced in   " class="contact-input" required="" />
                        </div>
                        <div class="form-input">
                            <textarea name="address" id="w3lMessage" placeholder="Address" required=""></textarea>
                        </div>
                        <div class="input-grids">
                            <input type="password" name="password" id="w3lName" placeholder="Password" class="contact-input" required="" />

                        </div>

                        <br><br>
                        <button type="submit" name="register" class="btn btn-style btn-style-primary-2 .text-center" style="margin-left: 40%;">Register</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include './COMMON/commonfooter.php';
?>

<?php

include './CONNECTION/DbConnection.php';

if (isset($_REQUEST['register'])) {

    $Name = $_REQUEST['fname'];
    $Phone = $_REQUEST['phone'];
    $Exp = $_REQUEST['exp'];
    $Address = $_REQUEST['address'];
    $Email = $_REQUEST['email'];
    $Password = $_REQUEST['password'];

    $qryCheck = "SELECT COUNT(*) AS cnt FROM `photographer` WHERE `pemail` = '$Email' OR `pphoneno` = '$Phone'";

    $qryOut = mysqli_query($conn, $qryCheck);

    $fetchData = mysqli_fetch_array($qryOut);

    if ($fetchData['cnt'] > 0) {
        echo "<script>alert('Already exist an Account with same Email / Phone Number');window.location = 'userRegister.php';</script>";
    } else {

        $qryReg = "INSERT INTO `photographer`(`pname`,`pemail`,`paddress`,`pphoneno`,`area`)VALUES('$Name','$Email','$Address','$Phone','$Exp')";
        $qryLog = "INSERT INTO login(`reg_id`, `email`, `password`, `type`) VALUES((select max(pid) from photographer), '$Email', '$Password', 'PHOTOGRAPHER')";

         echo $qryReg . "&& " . $qryLog;

        if ($conn->query($qryReg) == TRUE && $conn->query($qryLog) == TRUE) {
            echo "<script>alert('Registration Success');window.location = 'login.php';</script>";
        } else {
            echo "<script>alert('Registration Failed');window.location = 'userregistration.php';</script>";
        }
    }   
}

?>