<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head runat="server">
    <title></title>

    <style type="text/css">
        .auto-style1 {
            width: 100%;
        }

        .auto-style4 {
            height: 80px;
        }

        .auto-style5 {
            width: 327px;
            height: 81px;
        }

        .auto-style6 {
            width: 785px;
            text-align: left;
        }

        .auto-style7 {
            width: 444px;
            height: 124px;
        }

        .auto-style8 {
            width: 61px;
            height: 70px;
        }

        .auto-style9 {
            width: 112px;
            height: 66px;
        }

        .auto-style10 {
            width: 88px;
            height: 74px;
        }

        .auto-style11 {
            width: 886px;
            text-align: center;
        }

        .auto-style12 {
            width: 173px;
        }

        .auto-style14 {
            width: 624px;
            height: 93px;
        }

        .auto-style15 {}

        .auto-style16 {
            width: 101px;
        }

        .auto-style17 {
            width: 990px;
        }
    </style>
</head>

<body>

    <div>
        <table class="auto-style1">
            <tr>
                <td class="auto-style4">
                    <table class="auto-style1">
                        <tr>
                            <td class="auto-style6">
                                <img alt="" class="auto-style7" src="Images/dp_hm_slider03.jpg" />
                            </td>
                            <td style="text-align: right">
                                <img alt="" class="auto-style5" src="Images/payment-gateway-security.jpg" />
                            </td>
                        </tr>
                    </table>
                </td>

            </tr>
            <tr>
                <td class="auto-style15">
                    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>

                    <fieldset>
                        <legend style="font-weight: 700; text-align: center; font-size: large;">Enter Your Card Details</legend>
                        <table class="auto-style1">
                            <tr>
                                <td class="auto-style20"></td>
                                <td class="auto-style22"></td>
                                <td class="auto-style20"></td>
                                <td class="auto-style20"></td>
                            </tr>
                            <form method="POST">
                                <tr>
                                    <td>&nbsp;</td>

                                    <td class="auto-style18">Choose your card type</td>
                                    <td style="vertical-align:middle;">

                                        <input type="radio" name="test" value="small" checked>
                                        <img src="Images/1391796960_payment_method_card_visa.png" alt="Smiley face" height="31" width="58"><input type="radio" name="test" value="small" checked>
                                        <img src="Images/1391796956_payment_method_master_card.png" alt="Smiley face" height="31" width="58">
                                    </td>
                                    <td>&nbsp;</td>
                                </tr>
                                <form>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="auto-style18">Enter your card number</td>
                                        <td>
                                            <input type="text" name="cardno" maxlength="16" />


                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="auto-style18">Enter 4 digit Confirmation PIN</td>
                                        <td>
                                            <input type="text" name="pinno" maxlength="4" />
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="auto-style26">&nbsp;</td>
                                        <td>
                                            <input type="checkbox" name="terms" value="terms" CssClass="auto-style25">

                                            <span class="auto-style25">&nbsp;I Accept the Terms &amp; Conditions</span>
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="auto-style23">&nbsp;</td>
                                        <td>
                                            <input type="submit" value="Submit" name="sub" />
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="auto-style23">&nbsp;</td>
                                        <td>

                                </form>
                </td>
                <td>&nbsp;</td>
            </tr>
            <?php
            session_start();
            include '../CONNECTION/DbConnection.php';

            $carttid = $_REQUEST['carttid'];
            $product_id = $_REQUEST['product_id'];
            $stock = $_REQUEST['stock'];
            $neededstock = $_REQUEST['neededstock'];
            $updated_stock = $stock - $neededstock;

            echo $carttid;
            if (isset($_REQUEST["sub"])) {


                $qry1 = "UPDATE `tb_product` SET `stocks`='$updated_stock' WHERE `productcode`='$product_id'";
                echo $qry1;
                $qryout1 = mysqli_query($conn, $qry1);

                $ary = " UPDATE tb_cart SET `status`='Paid',`stock`='$neededstock' WHERE cart_id='$carttid'";
                $qryout = mysqli_query($conn, $ary);

                // echo $ary;
                if ($conn->query($qry1) == TRUE && $conn->query($ary) == TRUE) { {
                        echo "<script>
            alert(\"Successfully paid\");
            window.location = (\"../USER/userHome.php\")
        </script>";
                    }
                }
            }
            ?>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td class="auto-style21"></td>
                <td class="auto-style24"></td>
                <td class="auto-style21"></td>
                <td class="auto-style21"></td>
            </tr>
            <tr>
                <td>&nbsp;</td>

                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td class="auto-style23">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
        </table>
        </fieldset>
        </td>
        </tr>
        <tr>

            <td class="auto-style4">
                <table class="auto-style1">
                    <tr>
                        <td class="auto-style12">
                            <img alt="" class="auto-style8" src="Images/secure.jpg" /><img alt="" class="auto-style9" src="Images/firstdataglobal_cardinal_centinel_3d-secure_b909dac69bbd832054c1bf467e389c8f_verified_by_visa_1.gif" />
                        </td>
                        <td class="auto-style11">
                            <img alt="" class="auto-style14" src="Images/seq.JPG" />
                        </td>
                        <td style="text-align: right">
                            <img alt="" class="auto-style10" src="Images/ImgSml_PaymentGateway.jpg" />
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </table>
    </div>


</body>

</html>