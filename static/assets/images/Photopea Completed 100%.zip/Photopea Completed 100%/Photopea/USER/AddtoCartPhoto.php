<?php
session_start();
include '../CONNECTION/DbConnection.php';


$cusid = $_REQUEST['cusid'];
$picid = $_REQUEST['picid'];
$phtid = $_REQUEST['phtid'];
$item = $_REQUEST['item'];
$mdate =  date("Y/M/d");

$query = "INSERT INTO `pht_cart` (`cusid`,`picid`,`phtid`,`item`,`date`,`status`)VALUES ('$cusid','$picid','$phtid','$item','$mdate','incart')";
// echo $query;
$result = mysqli_query($conn, $query);

if ($result === TRUE) {
    echo "<script type = \"text/javascript\">
					alert(\"Item Added To cart\");
					window.location = (\"viewphotos.php\")
				</script>";
}
