<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './userHeader.php';

$uid = $_SESSION['uid'];

?>
<style>
    #qty {
        padding: 6px;
        width: 80px;
        margin: 5px;
        outline: none;
        border: 1px solid grey;
        border-radius: 5px;
    }

    input[type="submit"] {
        border: none;
        background-color: white;
        color: green;
        font-weight: bolder;
    }
</style>

<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Product Cart</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `tb_cart` C , `tb_product` P,`shop` S WHERE C.`cusid`='$uid' AND C.`centerid`=S.`s_id` AND C.`itemid`= P.`productcode` AND C.`status`='incart'");
            while ($rs = mysqli_fetch_array($res)) {

                $centerid = $rs['s_id'];
                $stock = $rs['stocks'];
                $carttid = $rs['cart_id'];
                $product_id = $rs['productcode'];

            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <h6 style="font-family: 'Courier New', Courier, monospace;float:right;"><?php echo $rs['date'] ?></h6>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['productname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['brand'] ?>-<?php echo $rs['category'] ?></a></h5>
                                <h5 class="color-1"><a style="color: black;" href="#blog">Warranty <?php echo $rs['warranty'] ?> Year</a></h5>
                                <h4><a href="#blog"><?php echo $rs['sname'] ?></a>
                                    <h4><a href="#blog"> Stock <span id="cnt"> <?php echo $rs['stocks'] ?></span></a>
                                    </h4>
                                    <p><?php echo $rs['features'] ?></p><br>
                                    <form action="../Payment/First.php">
                                        <input id="qty" type="number" max=<?php echo $stock; ?> placeholder="Stock" min=0 required name="neededstock">
                                        <br>
                                        <?php
                                        if ($stock == 0) {
                                            echo "<h4 style='color:red;'>Out of Stock</h4>";
                                        } else {
                                        ?>
                                            <input type="submit" value="Pay">
                                            <input type="hidden" name="carttid" value="<?php echo $carttid ?>">
                                            <input type="hidden" name="product_id" value="<?php echo $product_id ?>">
                                            <input type="hidden" name="stock" value="<?php echo $stock ?>">

                                        <?php

                                        }
                                        ?>

                                        <a href="RemoveFromCart.php?cartid=<?php echo $rs['cart_id'] ?>" class=".text-center" style="color:red;float:right">Remove </a>
                            </div>
                        </div>
                    </div>

                    </form>

                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>

<!--########################### Photo Cart ########################### -->

<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Photo Cart</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `pht_cart` C ,`photographes` Ph, `photographer` P WHERE C.`cusid` = '$uid' AND C.`phtid`= P.`pid` AND C.`picid` =  Ph.`photoid` AND C.`status` = 'incart'");
            while ($rs = mysqli_fetch_array($res)) {

                $pid = $rs['pid'];
                $stock = $rs['stock'];
                $phtcart_id = $rs['phtcart_id'];
                $photoid = $rs['photoid'];

            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <h6 style="font-family: 'Courier New', Courier, monospace;float:right;"><?php echo $rs['date'] ?></h6>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['name'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['desc'] ?>-<?php echo $rs['name'] ?></a></h5>

                                <h4><a href="#blog"> Stock <span id="cnt"> <?php echo $rs['stock'] ?></span></a>
                                </h4>
                                <form action="First.php">
                                    <input id="qty" type="number" max=<?php echo $stock; ?> placeholder="Stock" min=0 required name="neededstock">
                                    <br>
                                    <?php
                                    if ($stock == 0) {
                                        echo "<h4 style='color:red;'>Out of Stock</h4>";
                                    } else {
                                    ?>
                                        <input type="submit" value="Pay">
                                        <input type="hidden" name="phtcart_id" value="<?php echo $phtcart_id ?>">
                                        <input type="hidden" name="photoid" value="<?php echo $photoid ?>">
                                        <input type="hidden" name="stock" value="<?php echo $stock ?>">

                                    <?php

                                    }
                                    ?>

                                    <a href="RemovePhotoFromCart.php?phtcart_id=<?php echo $rs['phtcart_id'] ?>" class=".text-center" style="color:red;float:right">Remove </a>
                            </div>
                        </div>
                    </div>

                    </form>

                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>