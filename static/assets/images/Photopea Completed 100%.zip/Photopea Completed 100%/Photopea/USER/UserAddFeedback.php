<?php
session_start();
$uid = $_SESSION['uid'];
// print $uid;
include './userHeader.php';
include '../CONNECTION/DbConnection.php';
?>

<!-- contact -->
<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> Add Feedback </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
            <div class="row contact-block .text-center" style="justify-content: center;">
                <div class="col-md-7 contact-right mt-md-0 mt-4">
                    <form method="post">
                        <div class="form-input">
                            <textarea name="feedback" id="w3lMessage" placeholder="Feedback" required=""></textarea>
                        </div>
                        <br><br>
                        <button type="submit" name="send" class="btn btn-style btn-style-primary-2 .text-center" style="margin-left: 40%;">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
?>

<?php
if (isset($_REQUEST['send'])) {
    $Feedback = $_REQUEST['feedback'];


    $qrySnd = "INSERT INTO `feedback`(`uid`,`feedback`) VALUES('$uid','$Feedback')";
    //echo $qrySnd;

    if ($conn->query($qrySnd) == TRUE) {
        echo "<script>alert('Thank you for Your Valuable Feedback'); 
        window.location = 'userHome.php';</script>";
    }
}

?>