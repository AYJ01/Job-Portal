<?php
session_start();
include './userHeader.php';
include '../CONNECTION/DbConnection.php';
$centerid = $_GET['centerid'];
$uid = $_SESSION['uid'];
?>


<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Products </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM tb_product WHERE centerid='$centerid'");
            while ($rs = mysqli_fetch_array($res)) {
                $cid= $rs['centerid'];
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                        <a  style="color: red;float:right;margin-right: 5px;;"href='AddtoCartProcess.php?pid=<?php echo $rs['productcode']?>&cusid=<?php echo $uid?>&centerid=<?php echo $cid?>&item=<?php echo $rs['productname']?>' style="float:right; margin:10px;"> Add to <i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['productname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['brand'] ?>-><?php echo $rs['category'] ?> </a></h5>

                                <h4><a href="#blog"><?php echo $rs['productname'] ?></a>
                                </h4>
                                <h4><a href="#blog">💲<?php echo $rs['price'] ?> </a>
                                <h4><a href="#blog">Stock <span id ="cnt"><?php echo $rs['stocks'] ?></span> </a>
                                </h4>
                                <p><?php echo $rs['features'] ?></p>
                            
                            </div>
                        </div>
                    </div>
                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>