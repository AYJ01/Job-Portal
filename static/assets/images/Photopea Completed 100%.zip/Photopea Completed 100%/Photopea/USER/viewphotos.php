<?php
include './userHeader.php';
include '../CONNECTION/DbConnection.php';
?>


<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">PhotoGraphes</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT `photographer`.*,`photographes`.* FROM photographer,photographes WHERE photographer.`pid`=photographes.`takenby`");
            while ($rs = mysqli_fetch_array($res)) {
                $stock = $rs['stock'];
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['pname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a style="color:black;" href="#blog">Stock <span id="cnt"><?php echo $stock; ?></span> </a></h5>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['name'] ?>💲<?php echo $rs['price'] ?></a></h5>
                                <h4><a href="#blog"><?php echo $rs['pemail'] ?>[<?php echo $rs['pphoneno'] ?>]</a>
                                </h4>
                                <p><?php echo $rs['desc'] ?></p><br>
                                <?php
                                if ($stock == 0) {
                                    echo "<h4 style='color:red;'>Out of Stock</h4>";
                                } else {
                                ?>
                                    <a class="btn btn-outline-success" href="viewPhotoPro.php?picid=<?php echo $rs['photoid'] ?>&takenBy=<?php echo $rs['pid'] ?>" style="margin-left: 25%;"> View </a>

                                    <a class="btn btn-outline-primary" href="AddFeedtoPhoto.php?picid=<?php echo $rs['photoid'] ?>&phtid=<?php echo $rs['pid'] ?>">Feedback </a>
                                <?php

                                }
                                ?>
                            </div>  
                        </div>
                    </div>
                </div>

            <?php

            }
            ?>
        </div>
    </div>
</section>

<?php
include '../COMMON/commonfooter.php';
?>