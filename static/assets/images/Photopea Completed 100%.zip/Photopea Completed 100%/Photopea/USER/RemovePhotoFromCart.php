<?php
session_start();
include '../CONNECTION/DbConnection.php';


$phtcart_id = $_REQUEST['phtcart_id'];

$query = " DELETE FROM pht_cart WHERE phtcart_id='$phtcart_id' ";
$result = mysqli_query($conn, $query);

//  echo $query;

if ($result === TRUE) {
    echo "<script type = \"text/javascript\">
					alert(\"Item Removed from cart\");
					window.location = (\"CustomerCart.php\")
				</script>";
}
