<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './shopHeader.php';

$productcode = $_GET['productid'];

?>

<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Update Stock </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
            <div class="row contact-block .text-center">
                <div class="col-md-7 contact-right mt-md-0 mt-4">
                    <form method="post" enctype="multipart/form-data">
                        <div class="input-grids">
                            <input type="text" name="stock" id="w3lName" placeholder="S t o c k" class="contact-input" required="" />
                            <button type="submit" name="register" class="btn btn-style btn-style-primary-2 .text-center">Update</button>

                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php

if (isset($_REQUEST['register'])) {

    $stock = $_REQUEST['stock'];


    $qryReg = "UPDATE tb_product SET `stocks`='$stock' WHERE `productcode`='$productcode'";
    echo $qryReg;

    if ($conn->query($qryReg) == TRUE) {
        echo "<script>alert(' Success');window.location = 'addproduct.php';</script>";
    } else {
        echo "<script>alert(' Failed');window.location = 'addproduct.php';</script>";
    }
}
?>
<?php
include 'shopfooter.php';
?>