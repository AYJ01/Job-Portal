<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './shopHeader.php';

$uid = $_SESSION['uid'];

?>

<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> User Bookings</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `tb_cart` C , `tb_product` P,`shop` S,`user` u WHERE C.`centerid`='$uid' AND C.`centerid`=S.`s_id` AND C.`itemid`= P.`productcode` AND c.`cusid`=u.`uid`AND  C.`status`='Paid' and c.`usertype`='USER'");
            while ($rs = mysqli_fetch_array($res)) {

                $centerid = $rs['s_id'];
            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <h6 style="font-family: 'Courier New', Courier, monospace;float:right;"><?php echo $rs['date'] ?></h6>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['productname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['brand'] ?>-<?php echo $rs['category'] ?></a></h5>
                                <h5 class="color-1"><a style="color: black;" href="#blog">👤 <?php echo $rs['uname'] ?> </a></h5>
                                <h4><a href="#blog">✉️<?php echo $rs['uemail'] ?></a>
                                    <h4><a href="#blog"> Stock <span id="cnt"> <?php echo $rs['stock'] ?></span></a>
                                    </h4>
                                    <p>🏠<?php echo $rs['uaddress'] ?></p><br>
                                    <p style=" color:#FD5C63;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif ;">Paid</p><br>
                                    <!-- <a href='../Payment/First.php?carttid=<?php echo $rs['cart_id'] ?>' class=".text-center" style="color:green;font-weight:bold">Pay </a>
                                <a href="RemoveFromCart.php?cartid=<?php echo $rs['cart_id'] ?>" class=".text-center" style="color:red;float:right">Remove </a> -->
                            </div>
                        </div>
                    </div>
                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>



<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> PHOTOGRAPHER Bookings</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `tb_cart` C , `tb_product` P,`shop` S,`photographer` ph WHERE C.`centerid`='$uid' AND C.`centerid`=S.`s_id` AND C.`itemid`= P.`productcode` AND c.`cusid`=ph.`pid`AND  C.`status`='Paid' AND c.`usertype`='PHOTO'");
            while ($rs = mysqli_fetch_array($res)) {

                $centerid = $rs['s_id'];
            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <h6 style="font-family: 'Courier New', Courier, monospace;float:right;"><?php echo $rs['date'] ?></h6>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['productname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['brand'] ?>-<?php echo $rs['category'] ?></a></h5>
                                <h5 class="color-1"><a style="color: black;" href="#blog">👤 <?php echo $rs['pname'] ?> </a></h5>
                                <h4><a href="#blog">✉️<?php echo $rs['pemail'] ?></a>
                                    <h4><a href="#blog"> Stock <span id="cnt"> <?php echo $rs['stock'] ?></span></a>
                                    </h4>
                                    <p>🏠<?php echo $rs['paddress'] ?></p><br>
                                    <p style=" color:#FD5C63;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif ;">Paid</p><br>
                                    <!-- <a href='../Payment/First.php?carttid=<?php echo $rs['cart_id'] ?>' class=".text-center" style="color:green;font-weight:bold">Pay </a>
                                <a href="RemoveFromCart.php?cartid=<?php echo $rs['cart_id'] ?>" class=".text-center" style="color:red;float:right">Remove </a> -->
                            </div>
                        </div>
                    </div>
                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>

<?php
include 'shopfooter.php';
?>