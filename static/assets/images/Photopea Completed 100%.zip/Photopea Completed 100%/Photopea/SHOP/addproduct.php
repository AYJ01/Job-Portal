<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './shopHeader.php';
?>

<style>
    #a{
       text-align: center; 
       margin:10px auto;
       color: orange;
       font-weight: bolder;
       letter-spacing: 1px;
       font-family: sans-serif;
       padding: 10px;
       background-color: white;
    }
</style>
<!-- contact -->
<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Add product </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
            <div class="row contact-block .text-center">
                <div class="col-md-7 contact-right mt-md-0 mt-4">
                    <form method="post" enctype="multipart/form-data">
                        <div class="input-grids">
                            <input type="text" name="pname" id="w3lName" placeholder="Product Name" class="contact-input" required="" />
                            <input type="text" name="Features" id="w3lName" placeholder="Features" class="contact-input" required="" />
                            <input type="number" id="w3lFeatures" placeholder="Price" name="price" id="w3lSender" class="contact-input" required="" />
                            <input type="number" id="w3lFeatures" placeholder="Warranty" name="Warranty" id="w3lSender" class="contact-input" required="" />
                            <input type="number" id="w3lFeatures" placeholder="Stock" name="stock" id="w3lSender" class="contact-input" required="" />
                        </div>
                        <select name="pbrand">
                            <option>....Choose Brand....</option>
                            <?php
                            $res = mysqli_query($conn, "SELECT * from `brand`");
                            while ($rs = mysqli_fetch_array($res)) {
                                echo "<option>" . $rs['1'] . "</option>";
                            }
                            ?>
                        </select>

                        <select name="pcategory">
                            <option>....Choose Category....</option>
                            <?php
                            $res = mysqli_query($conn, "SELECT * from `category`");
                            while ($rs = mysqli_fetch_array($res)) {
                                echo "<option>" . $rs['1'] . "</option>";
                            }

                            ?>

                        </select>
                        <div class="input-grids">
                            <input type="file" name="file" id="w3lName" placeholder="file" class="contact-input" required="" />

                        </div>

                        <br><br>
                        <button type="submit" name="register" class="btn btn-style btn-style-primary-2 .text-center">Add</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php

$uid = $_SESSION['uid'];
if (isset($_REQUEST['register'])) {

    $pname = $_REQUEST['pname'];
    $Features = $_REQUEST['Features'];
    $price = $_REQUEST['price'];
    $Warranty = $_REQUEST['Warranty'];
    $pbrand = $_REQUEST['pbrand'];
    $pcategory = $_REQUEST['pcategory'];
    $stock = $_REQUEST['stock'];

    $filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
    $folder = "image/" . $filename;

    if (move_uploaded_file($tempname, '../assets/image/' . $filename)) {
        $qryCheck = "SELECT COUNT(*) AS cnt FROM `tb_product` WHERE `productname` = '$pname' OR `price` = '$price'";

        $qryOut = mysqli_query($conn, $qryCheck);

        $fetchData = mysqli_fetch_array($qryOut);

        if ($fetchData['cnt'] > 0) {
            echo "<script>alert('Already exist ');
             window.location = 'addproduct.php';
            </script>";
        } else {

            $qryReg = "INSERT INTO tb_product(`centerid`,`productname`,`category`,`brand`,`price`,`warranty`,`features`,`image`,`stocks`)VALUES('$uid','$pname','$pcategory','$pbrand','$price','$Warranty','$Features','$filename','$stock')";

            echo $qryReg . "&& ";

            if ($conn->query($qryReg) == TRUE) {
                echo "<script>alert(' Success');window.location = 'addproduct.php';</script>";
            } else {
                echo "<script>alert(' Failed');window.location = 'addproduct.php';</script>";
            }
        }
    }
}
?>



<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> My Products</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php

            $res = mysqli_query($conn, "SELECT * FROM tb_product WHERE centerid=$uid");
            while ($rs = mysqli_fetch_array($res)) {
                $stock = $rs['stocks'];
                $productcode = $rs['productcode'];
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <a href='removeproduct.php?id=<?php echo $rs['productcode'] ?>' style="float:right; margin:10px;">❌</a>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['productname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['brand'] ?>-><?php echo $rs['category'] ?> </a></h5>

                                <h4><a href="#blog"><?php echo $rs['productname'] ?></a>
                                </h4>
                                <h4><a href="#blog">stock <span id="cnt"><?php echo $stock ?></span></a>
                                </h4>
                                <h4><a href="#blog">💲<?php echo $rs['price'] ?> </a>
                                </h4>
                                <p><?php echo $rs['features'] ?></p>
                                <br>
                                <a href="updatestock.php?productid=<?php echo $productcode ?>" id='a'>Update</a>

                            </div>
                        </div>
                    </div>
                </div>

            <?php

            }
            ?>
        </div>
    </div>
</section>

<?php
include 'shopfooter.php';
?>