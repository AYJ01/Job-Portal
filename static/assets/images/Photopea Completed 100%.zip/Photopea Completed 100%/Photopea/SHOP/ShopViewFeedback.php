<?php
include './shopHeader.php';
include '../CONNECTION/DbConnection.php';
$data = "SELECT user.*,`usrshpfeedback`.* FROM `user`,`usrshpfeedback` WHERE `usrshpfeedback`.`uid` = `user`.`uid`;
";
$qry = mysqli_query($conn, $data);
if (mysqli_num_rows($qry) < 1) {
} else {
?>

    <section class="w3l-grids-block-5 py-5">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
                <h3 class="title-style">User Feedbacks</h3>
                <p class="lead mt-2"></p>
            </div>
        </div>
        <table border='2' align="center" class="table  table-bordered text-center table-striped" style="width: 60%; margin-top: -1%;">
            <tr>
                <th>Date</th>
                <th>Name</th>
                <th>Email</th>
                <th>Feedback</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_array($qry)) {
            ?>

                <tr>
                    <td>
                        <?php
                        echo $row['date']
                        ?>
                    </td>
                    <td>
                        <?php
                        echo $row['uname']
                        ?>
                    </td>

                    <td>
                        <?php
                        echo $row['uemail']
                        ?>
                    </td>

                    <td>
                        <?php
                        echo $row['feedback']
                        ?>
                    </td>

                </tr>
        <?php
            }
        }

        ?>
        </table>
    </section>

    <?php
    $data = "SELECT `photographer`.*,`phoshpfeedback`.* FROM `photographer`,`phoshpfeedback` WHERE `phoshpfeedback`.`uid` = `photographer`.`pid`;
";
    $qry = mysqli_query($conn, $data);
    if (mysqli_num_rows($qry) < 1) {
    } else {
    ?>

        <section class="w3l-grids-block-5 py-5">
            <div class="container py-md-5 py-4">
                <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
                    <h3 class="title-style">Photographer Feedbacks</h3>
                    <p class="lead mt-2"></p>
                </div>
            </div>
            <table border='2' align="center" class="table  table-bordered text-center table-striped" style="width: 60%; margin-top: -1%;">
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Feedback</th>
                </tr>
                <?php
                while ($row = mysqli_fetch_array($qry)) {
                ?>

                    <tr>
                        <td>
                            <?php
                            echo $row['date']
                            ?>
                        </td>
                        <td>
                            <?php
                            echo $row['pname']
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $row['pemail']
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $row['feedback']
                            ?>
                        </td>

                    </tr>
            <?php
                }
            }

            ?>
            </table>
        </section>

        <?php
        include 'shopfooter.php';
        ?>