<?php
session_start();
include './COMMON/commonheader.php';
?>

<!-- contact -->
<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Login </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width: 1000px;">
            <div class="row contact-block .text-center" style="justify-content: center;">
                <div class="col-md-7 contact-right mt-md-0 mt-4">
                    <form method="post">
                        <div class="input-grids">
                            <input type="email" name="Email" id="w3lName" placeholder="Username" class="contact-input" required="" />
                            <input type="password" name="Password" id="w3lSender" placeholder="Password" class="contact-input" required="" />

                        </div>
                        <br><br>
                        <button type="submit" name="login" class="btn btn-style btn-style-primary-2 .text-center" style="margin-left: 40%;">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include './COMMON/commonfooter.php';
?>



<?php
include './CONNECTION/DbConnection.php';

if (isset($_REQUEST['login'])) {
    $email = $_REQUEST['Email'];
    $password = $_REQUEST['Password'];
    $qry = "SELECT * FROM login WHERE `email` = '$email' AND `password` = '$password'";
    $result = mysqli_query($conn, $qry);
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $uid = $data['reg_id'];
        $type = $data['type'];

        $_SESSION['uid'] = $uid;
        $_SESSION['type'] = $type;

        if ($type == 'ADMIN') {
            echo "<script>alert('Welcome to AdminHome '); window.location='ADMIN/adminHome.php'</script>";
        } else  if ($type == 'SHOP') {
            echo "<script>alert('Welcome to ShopHome'); window.location='SHOP/shopHome.php'</script>";
        } else if ($type == 'PHOTOGRAPHER') {
            echo "<script>alert(' You logined as Photographer '); window.location='PHOTOGRAPHER/photoHome.php'</script>";
        } else if ($type == 'USER') {
            echo "<script>alert('Welcome User'); window.location='USER/userHome.php'</script>";
        } else {
            echo "<script>alert('Login Failed')</script>";
        }
    } else {
        echo "<script>alert('Invalid Email / Password'); window.location='login.php'</script>";
    }
}
?>