<?php
session_start();
include '../CONNECTION/DbConnection.php';


$id = $_REQUEST['id'];

$query = " DELETE FROM photographes WHERE photoid='$id' ";
$result = mysqli_query($conn, $query);

if ($result === TRUE) {
    echo "<script type = \"text/javascript\">
					alert(\" Removed \");
					window.location = (\"addphotos.php\")
				</script>";
}
