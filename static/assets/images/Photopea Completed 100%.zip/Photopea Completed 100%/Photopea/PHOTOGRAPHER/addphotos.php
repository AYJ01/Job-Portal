<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './photoHeader.php';
?>
<style>
    h3 {
        margin: 10px;
    }

    #cnt {
        background-color: pink;
        padding: 8px;
        margin: 10px;
        border-radius: 100%;
    }
</style>

<!-- contact -->
<section class="w3l-contact py-5" id="contact">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Add Photos </h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
            <div class="row contact-block .text-center">
                <div class="col-md-7 contact-right mt-md-0 mt-4" style="margin-left: 20%;">
                    <form method="post" enctype="multipart/form-data">
                        <div class="input-grids">
                            <input type="text" name="pname" id="w3lName" placeholder="Photo Name" class="contact-input" required="" />
                            <input type="text" name="features" id="w3lDescription" placeholder="Description" class="contact-input" required="" />
                            <input type="number" id="w3lFeatures" placeholder="Price" name="price" id="w3lSender" class="contact-input" required="" />
                            <input type="number" id="w3lFeatures" placeholder="Stock" name="stock" id="w3lSender" class="contact-input" required="" />

                        </div>
                        <div class="input-grids">
                            <input type="file" name="file" id="w3lName" placeholder="file" class="contact-input" required="" />
                        </div>
                        <br><br>
                        <button type="submit" name="register" class="btn btn-style btn-style-primary-2 .text-center">Add</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php

$uid = $_SESSION['uid'];
if (isset($_REQUEST['register'])) {
    $Desc = $_REQUEST['features'];
    $pname = $_REQUEST['pname'];

    $price = $_REQUEST['price'];
    $stock = $_REQUEST['stock'];

    $filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
    $folder = "image/" . $filename;

    if (move_uploaded_file($tempname, '../assets/image/' . $filename)) {

        $qryCheck = "SELECT COUNT(*) AS cnt FROM `photographes` WHERE `name` = '$pname' OR `price` = '$price'";
        echo $qryCheck;
        $qryOut = mysqli_query($conn, $qryCheck);

        $fetchData = mysqli_fetch_array($qryOut);

        if ($fetchData['cnt'] > 0) {
            echo "<script>alert('Already exist ');
             window.location = 'addphotos.php';
            </script>";
        } else {

            $qryReg = "INSERT INTO `photographes`(`takenby`,`name`,`image`,`price`,`desc`,`stock`)VALUES('$uid','$pname','$filename','$price','$Desc','$stock')";

            echo $qryReg . "&& ";

            if ($conn->query($qryReg) == TRUE) {
                echo "<script>alert(' Success');window.location = 'addphotos.php';</script>";
            } else {
                echo "<script>alert(' Failed');window.location = 'addphotos.php';</script>";
            }
        }
    } else {
        echo "no file selected";
    }
}
?>


<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> My Photos</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php

            $res = mysqli_query($conn, "SELECT ph.*,p.* FROM `photographes` ph,`photographer` p WHERE ph.takenby='$uid' AND ph.takenby=p.`pid`");
            while ($rs = mysqli_fetch_array($res)) {
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <a href='removephoto.php?id=<?php echo $rs['photoid'] ?>' style="float:right; margin:10px;">❌</a>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"> Taken By :-<?php echo $rs['pname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog">📞<?php echo $rs['pphoneno'] ?> </a></h5>
                                <h5 class="color-1"><a href="#blog">✉️<?php echo $rs['pemail'] ?> </a></h5>
                                <h5 class="color-1"><a style="color:black;" href="#blog">Stock <span id="cnt"><?php echo $rs['stock']; ?></span> </a></h5>
                                <h4><a href="#blog"><?php echo $rs['name'] ?></a>
                                </h4>
                                <h4><a href="#blog">💲<?php echo $rs['price'] ?> </a>
                                </h4>
                                <p><?php echo $rs['desc'] ?></p>

                            </div>
                        </div>
                    </div>
                </div>

            <?php

            }
            ?>
        </div>
    </div>
</section>

<?php
include 'photofooter.php';
?>