<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './photoHeader.php';

$uid = $_SESSION['uid'];

?>

<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"> orders</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `pht_cart` C, `photographes` Ph, `photographer` P,`user` U  WHERE C.`phtid`='$uid' AND C.`phtid` = P.`pid` AND C.`picid`= Ph.`photoid` AND C.`cusid`= U.`uid` AND C.`status`='Paid' AND C.`usertype` = 'USER'");
            while ($rs = mysqli_fetch_array($res)) {


            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <h6 style="font-family: 'Courier New', Courier, monospace;float:right;"><?php echo $rs['date'] ?></h6>
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['image'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['image'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['uname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a style="color: black;" href="#blog">💲 <?php echo $rs['price'] ?>/- </a></h5>
                                <h4><a href="#blog"><?php echo $rs['uemail'] ?></a>
                                <h4><a href="#blog"> Stock <span id="cnt"> <?php echo $rs['stocks'] ?></span></a>
                                </h4>
                                <p><?php echo $rs['uaddress'] ?></p><br>
                                <p style=" color:#FD5C63;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif ; font-weight: bolder;"><?php echo $rs['status'] ?></p><br>
                                 
                            </div>
                        </div>
                    </div>
                </div>
            <?php

            }
            ?>
        </div>
    </div>
</section>

<?php
include 'photofooter.php';
?>