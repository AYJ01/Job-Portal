<?php
session_start();
include '../CONNECTION/DbConnection.php';


$bookid = $_REQUEST['bookid'];
$status = $_REQUEST['status'];

$query = "UPDATE `photobookings` SET `status`='$status' WHERE `pbookid`='$bookid'";
$result = mysqli_query($conn, $query);

if ($result === TRUE) {
    echo "<script type = \"text/javascript\">
					alert(\"sucess\");
					window.location = (\"Myorders.php\")
				</script>";
}
