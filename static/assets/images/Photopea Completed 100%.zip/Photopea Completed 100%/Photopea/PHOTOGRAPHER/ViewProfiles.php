<?php
session_start();
include '../CONNECTION/DbConnection.php';
include './photoHeader.php';

$uid = $_SESSION['uid'];
$count = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM `photographes` WHERE takenby='$uid'");
while ($rs = mysqli_fetch_array($count)) {

    $cnt = $rs['cnt'];
    
}
echo $cnt;
?>
<style>
    h3{
        margin:10px;
    }
    span{
        background-color: pink;
        padding: 8px;
        margin: 10px;
        border-radius: 100%;
    }
</style>

<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style"></h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM `photographer` WHERE pid='$uid'");
            while ($rs = mysqli_fetch_array($res)) {

                $pname = $rs['pname'];
                $pemail=$rs['pemail'];
                $pphoneno=$rs['pphoneno'];
                $area=$rs['area'];
                $paddress=$rs['paddress'];
            ?>


                <section class="w3l-contact py-5" id="contact">
                    <div class="container py-lg-5 py-md-4 py-2">
                        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
                            <h3 class="title-style">vIEW PROFILE </h3>
                            <h3>Uploads <span><?php echo $cnt;?></span></h3>
                            <p class="lead mt-2"></p>
                        </div>
                        <div class="mx-auto pt-lg-4 pt-md-5 pt-4 .text-center" style="max-width:1000px">
                            <div class="row contact-block .text-center">
                                <div class="col-md-7 contact-right mt-md-0 mt-4">
                                    <form method="post">
                                        <div class="input-grids">
                                            <input type="text" name="fname" id="w3lName" value="<?php echo $pname;?>" placeholder="Full Name" class="contact-input" required="" readonly />
                                            <input type="text" name="phone" maxlength="10" value="<?php echo $pphoneno;?>" pattern=[789][0-9]{9} id="w3lName" placeholder="Phone Number" class="contact-input" required=""  readonly/>
                                            <input type="email" name="email" id="w3lSender" value="<?php echo $pemail;?>"  placeholder="Email" class="contact-input" required="" readonly/>
                                            <input type="text" name="exp" id="w3lSender" placeholder="Specialiced in   " value="<?php echo $area;?>" class="contact-input" required="" readonly />
                                        </div>
                                        <div class="form-input">
                                            <textarea name="address" id="w3lMessage"  placeholder="<?php echo $paddress;?>" required=""></textarea>
                                        </div>
                                        <br><br>
                                        <!-- <button type="submit" name="register" class="btn btn-style btn-style-primary-2 .text-center">Register</button> -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            <?php

            }
            ?>
        </div>
    </div>
</section>