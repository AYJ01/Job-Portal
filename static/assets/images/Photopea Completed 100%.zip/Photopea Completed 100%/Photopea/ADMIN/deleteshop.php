<?php
session_start();
include '../CONNECTION/DbConnection.php';

$sid = $_REQUEST['id'];
$status = $_REQUEST['status'];

if ($status == 'pending') {

	$query = "UPDATE `login` SET `status`='$status' WHERE `reg_id`='$sid' AND `type`='SHOP'";
	$result = mysqli_query($conn, $query);
	// echo $query;
	if ($result == TRUE) {
		echo "<script type = \"text/javascript\">
        				alert(\"Delected\");
                        window.location = (\"viewShops.php\")
                        </script>";

		echo $query;
	}
}

?>