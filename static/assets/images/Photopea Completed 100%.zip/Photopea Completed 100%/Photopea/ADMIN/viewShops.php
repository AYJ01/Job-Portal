<?php
include 'adminheader.php';
include '../CONNECTION/DbConnection.php';
?>


<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Pending Shops</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT `shop`.*,`login`.* FROM `shop`,`login` WHERE `login`.`status` = 'pending' AND `login`.`type`='SHOP' AND `login`.`reg_id`=`shop`.`s_id`");
            while ($rs = mysqli_fetch_array($res)) {
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['photo'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['photo'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['sname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['sphone'] ?></a></h5>
                                <h4><a href="#blog"><?php echo $rs['semail'] ?></a>
                                </h4>
                                <p><?php echo $rs['saddress'] ?></p><br>
                                <span style="margin-left: 20%;">
                                    <a class="btn btn-outline-success" href="verifyShop.php?id=<?php echo $rs['s_id'] ?>&status=approved"> Approve</a>
                                </span>
                                <span style="margin-left:5%;">
                                    <a class="btn btn-outline-danger" href="verifyShop.php?id=<?php echo $rs['s_id'] ?>&status=reject"> Reject</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            <?php

            }
            ?>
        </div>
    </div>
</section>


<section class="w3l-grids-block-5 py-5">
    <div class="container py-md-5 py-4">
        <div class="title-heading-w3 text-center mx-auto mb-sm-5 mb-4" style="max-width:700px">
            <h3 class="title-style">Approved Shops</h3>
            <p class="lead mt-2"></p>
        </div>
        <div class="row justify-content-center">
            <?php
            $res = mysqli_query($conn, "SELECT `shop`.*,`login`.* FROM `shop`,`login` WHERE `login`.`status` = 'approved' AND `login`.`type`='SHOP' AND `login`.`reg_id`=`shop`.`s_id`");
            while ($rs = mysqli_fetch_array($res)) {
            ?>

                <div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info">
                            <a href="#blog"><img style="height: 200px;" src="../assets/image/<?php echo $rs['photo'] ?>" alt="" /></a>
                            <div class="blog-info">
                                <div class="d-flex align-items-center justify-content-between ">
                                    <a class="d-flex align-items-center" href="#blog" title="23k followers">
                                        <img class="img-fluid" src="../assets/image/<?php echo $rs['photo'] ?>" alt="admin" style="max-width:40px"> <span class="small ml-2"><?php echo $rs['sname'] ?></span>
                                    </a>
                                    <p class="date-text"></p>
                                </div>
                                <h5 class="color-1"><a href="#blog"><?php echo $rs['sphone'] ?></a></h5>
                                <h4><a href="#blog"><?php echo $rs['semail'] ?></a>
                                </h4>
                                <p><?php echo $rs['saddress'] ?></p><br>
                                <span style="margin-left:70%;">
                                    <a class="btn btn-outline-danger" href="deleteShop.php?id=<?php echo $rs['s_id'] ?>&status=pending"> Delete</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            <?php

            }
            ?>
        </div>
    </div>
</section>






<?php
include 'adminfooter.php';
?>