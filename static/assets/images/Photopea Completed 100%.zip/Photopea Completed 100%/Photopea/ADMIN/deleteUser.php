<?php
session_start();
include '../CONNECTION/DbConnection.php';

$uid = $_REQUEST['id'];
$status = $_REQUEST['status'];

if ($status == 'pending') {

	$query = "UPDATE `login` SET `status`='$status' WHERE `reg_id`='$uid' AND `type`='USER'";
	$result = mysqli_query($conn, $query);
	// echo $query;
	if ($result == TRUE) {
		echo "<script type = \"text/javascript\">
        				alert(\"Delected\");
                        window.location = (\"viewCustomers.php\")
                        </script>";

		echo $query;
	}
}

?>