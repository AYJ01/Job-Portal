-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2023 at 02:10 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `photopea`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `brand_id` bigint(50) NOT NULL AUTO_INCREMENT,
  `Brandname` varchar(50) NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `Brandname`) VALUES
(1, 'Dell'),
(2, 'Asus'),
(5, 'Apple'),
(6, 'HP'),
(7, 'Acer'),
(8, 'iBall'),
(9, 'Nvidia'),
(10, 'Intel'),
(11, 'Canon'),
(12, 'Corsair');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `catid` bigint(50) NOT NULL AUTO_INCREMENT,
  `catname` varchar(50) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `catname`) VALUES
(1, 'Ozure Variable N.D Filter'),
(2, 'Ozure Step Down Ring'),
(3, 'Ozure MCUV Filter'),
(4, 'Ozure Leveling Seat'),
(5, 'The Low Gravity Tripod Head (OZ-BK-25)'),
(6, 'Cover'),
(7, 'Filter Kit');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `l_id` int(20) NOT NULL AUTO_INCREMENT,
  `reg_id` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'pending',
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`l_id`, `reg_id`, `email`, `password`, `type`, `status`) VALUES
(0, '0', 'admin@gmail.com', 'admin', 'ADMIN', 'approved'),
(26, '5', 'bini@gmail.com', 'bini123', 'USER', 'approved'),
(27, '5', 'akhil@gmail.com', 'akhil123', 'PHOTOGRAPHER', 'approved'),
(31, '2', 'canon@gmail.com', 'canon123', 'SHOP', 'approved'),
(32, '6', 'midhun@gmail.com', 'midhun123', 'USER', 'approved'),
(33, '7', 'ram@gmail.com', '123', 'USER', 'pending'),
(34, '3', 'so@gmail.com', '123', 'SHOP', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `phoshpfeedback`
--

CREATE TABLE IF NOT EXISTS `phoshpfeedback` (
  `fid` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `sid` int(100) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `phoshpfeedback`
--

INSERT INTO `phoshpfeedback` (`fid`, `uid`, `sid`, `feedback`, `date`) VALUES
(6, 5, 2, 'good', 'Wed Jul 19 2023');

-- --------------------------------------------------------

--
-- Table structure for table `photographer`
--

CREATE TABLE IF NOT EXISTS `photographer` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(40) NOT NULL,
  `pemail` varchar(40) NOT NULL,
  `paddress` varchar(100) NOT NULL,
  `pphoneno` varchar(40) NOT NULL,
  `area` varchar(40) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `photographer`
--

INSERT INTO `photographer` (`pid`, `pname`, `pemail`, `paddress`, `pphoneno`, `area`) VALUES
(5, 'Akhil ', 'akhil@gmail.com', 'W97C+XHJ, Kandanad, Manakunnam, Kerala 682305', '9876543211', 'Wild Photography');

-- --------------------------------------------------------

--
-- Table structure for table `photographes`
--

CREATE TABLE IF NOT EXISTS `photographes` (
  `photoid` int(100) NOT NULL AUTO_INCREMENT,
  `takenby` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `stock` varchar(100) NOT NULL DEFAULT 'noval',
  PRIMARY KEY (`photoid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `photographes`
--

INSERT INTO `photographes` (`photoid`, `takenby`, `name`, `image`, `price`, `desc`, `stock`) VALUES
(1, '5', 'Nature ', 'nature.jpg', '1200', 'Munnar Beauty', '11'),
(6, '5', 'Nature 1', 'nature1-min-compressed.jpg', '100', 'Kuttanadan Padam ', '36');

-- --------------------------------------------------------

--
-- Table structure for table `pht_cart`
--

CREATE TABLE IF NOT EXISTS `pht_cart` (
  `phtcart_id` int(100) NOT NULL AUTO_INCREMENT,
  `cusid` varchar(100) DEFAULT NULL,
  `picid` varchar(100) DEFAULT NULL,
  `phtid` varchar(100) DEFAULT NULL,
  `item` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `usertype` varchar(100) DEFAULT 'USER',
  `stocks` varchar(100) DEFAULT '0',
  PRIMARY KEY (`phtcart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `pht_cart`
--

INSERT INTO `pht_cart` (`phtcart_id`, `cusid`, `picid`, `phtid`, `item`, `date`, `status`, `usertype`, `stocks`) VALUES
(10, '6', '1', '5', 'Nature', '2023/Jul/19', 'Paid', 'USER', '1');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `s_id` int(10) NOT NULL AUTO_INCREMENT,
  `sname` varchar(100) NOT NULL,
  `sphone` varchar(100) DEFAULT NULL,
  `saddress` varchar(100) DEFAULT NULL,
  `semail` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`s_id`, `sname`, `sphone`, `saddress`, `semail`, `photo`) VALUES
(2, 'Canon Image Square', '8975443544', 'No 41/2795B, North Avenue, Paramara Rd, Ernakulam, Kerala 682018', 'canon@gmail.com', 'canon.jpg'),
(3, 'Sony', '7412589632', 'No 41/2795B, North Avenue, Paramara Rd, Ernakulam, Kerala 68201', 'so@gmail.com', 'g5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_cart`
--

CREATE TABLE IF NOT EXISTS `tb_cart` (
  `cart_id` int(100) NOT NULL AUTO_INCREMENT,
  `cusid` varchar(100) DEFAULT NULL,
  `centerid` varchar(100) DEFAULT NULL,
  `itemid` varchar(100) DEFAULT NULL,
  `item` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `usertype` varchar(20) DEFAULT 'USER',
  `stock` varchar(100) DEFAULT '0',
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `tb_cart`
--

INSERT INTO `tb_cart` (`cart_id`, `cusid`, `centerid`, `itemid`, `item`, `date`, `status`, `usertype`, `stock`) VALUES
(39, '6', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'Paid', 'USER', '2'),
(40, '6', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'Paid', 'USER', '1'),
(41, '6', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'Paid', 'USER', '1'),
(42, '6', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'incart', 'USER', '0'),
(43, '5', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'Paid', 'PHOTO', '1'),
(45, '5', '2', '14', 'Ozure 13 Filter Kit (58mm)', '2023/Jul/19', 'Paid', 'PHOTO', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE IF NOT EXISTS `tb_product` (
  `productcode` bigint(50) NOT NULL AUTO_INCREMENT,
  `centerid` int(100) DEFAULT NULL,
  `productname` varchar(500) NOT NULL,
  `category` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `price` bigint(100) NOT NULL,
  `warranty` varchar(100) NOT NULL,
  `features` varchar(500) NOT NULL,
  `image` varchar(200) NOT NULL,
  `stocks` varchar(100) DEFAULT '0',
  PRIMARY KEY (`productcode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`productcode`, `centerid`, `productname`, `category`, `brand`, `price`, `warranty`, `features`, `image`, `stocks`) VALUES
(14, 2, 'Ozure 13 Filter Kit (58mm)', 'Cover', 'Canon', 1196, '1', 'Ozure 13 PCs Filter Kit Set Of 13 Different Camera Filters + Filter Stack Cap Black anodized Aluminum Housing Combination of most 13 popular filters Branded Storage Pouch', 'cam cover.jpg', '15'),
(15, NULL, '', '', '', 0, '', '', '', '8');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(40) NOT NULL,
  `uemail` varchar(40) NOT NULL,
  `uaddress` varchar(40) NOT NULL,
  `uphoneno` varchar(40) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `uname`, `uemail`, `uaddress`, `uphoneno`) VALUES
(5, 'Binimol', 'bini@gmail.com', 'W99G+26G, Manakunnam, Kerala 682305', '9876543210'),
(6, 'Midhun', 'midhun@gmail.com', 'Pizzaman, Chembumukku, Edappally, Kochi,', '9747691770'),
(7, 'Ram A', 'ram@gmail.com', 'Kochi', '9638527414');

-- --------------------------------------------------------

--
-- Table structure for table `usrphtofeedback`
--

CREATE TABLE IF NOT EXISTS `usrphtofeedback` (
  `pfid` int(100) NOT NULL AUTO_INCREMENT,
  `uid` varchar(100) NOT NULL,
  `picid` varchar(100) NOT NULL,
  `phtid` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  PRIMARY KEY (`pfid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usrphtofeedback`
--

INSERT INTO `usrphtofeedback` (`pfid`, `uid`, `picid`, `phtid`, `date`, `feedback`) VALUES
(2, '6', '1', '5', 'Mon Jul 17 2023', 'Good'),
(3, '6', '6', '5', 'Mon Jul 17 2023', 'Not bad');

-- --------------------------------------------------------

--
-- Table structure for table `usrshpfeedback`
--

CREATE TABLE IF NOT EXISTS `usrshpfeedback` (
  `fid` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `sid` int(100) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `usrshpfeedback`
--

INSERT INTO `usrshpfeedback` (`fid`, `uid`, `sid`, `feedback`, `date`) VALUES
(5, 6, 2, 'So good', 'Sat Jul 15 2023');
